
North American Mushrooms - v2 416x416augmented
==============================

This dataset was exported via roboflow.ai on May 2, 2021 at 6:31 PM GMT

It includes 256 images.
Mushroom are annotated in YOLO v4 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 6 versions of each source image:
* Randomly crop between 0 and 10 percent of the image
* Random rotation of between -15 and +15 degrees
* Random brigthness adjustment of between -10 and +10 percent
* Random exposure adjustment of between -7 and +7 percent


